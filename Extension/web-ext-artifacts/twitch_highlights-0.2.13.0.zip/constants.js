const const_n = 6;
const const_l = 2;
const const_offset = 5;
const const_from = 10;
const const_to = 50;
const const_isBasic = 1;
const const_automode = 1;